<div class="col-md-4 col-md-push-8">
    <ul class="footer-social">
        <?php if($settings->facebook !== null): ?>
            <li><a target="_blank" href="<?php echo e($settings->facebook); ?>" class="facebook"><i class="fa fa-facebook"></i></a></li>
        <?php endif; ?>

        <?php if($settings->twitter !== null): ?>
            <li><a target="_blank" href="<?php echo e($settings->twitter); ?>" class="twitter"><i class="fa fa-twitter"></i></a></li>
        <?php endif; ?>

        <?php if($settings->instagram !== null): ?>
            <li><a target="_blank" href="<?php echo e($settings->instagram); ?>" class="instagram"><i class="fa fa-instagram"></i></a></li>
        <?php endif; ?>

        <?php if($settings->youtube !== null): ?>
            <li><a target="_blank" href="<?php echo e($settings->youtube); ?>" class="youtube"><i class="fa fa-youtube"></i></a></li>
        <?php endif; ?>

        <?php if($settings->linkedin !== null): ?>
            <li><a target="_blank" href="<?php echo e($settings->linkedin); ?>" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
        <?php endif; ?>

    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\skillshub\resources\views/components/social-links.blade.php ENDPATH**/ ?>