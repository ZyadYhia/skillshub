<?php $__env->startSection('title'); ?>
    forgot password
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>

    <!-- Contact -->
    <div id="contact" class="section">

        <!-- container -->
        <div class="container">

            <!-- row -->
            <div class="row">

                <!-- login form -->
                <div class="col-md-6 col-md-offset-3">
                    <div class="contact-form">
                        <h4><?php echo e(__('web.forget_password')); ?></h4>
                        <?php echo $__env->make('web.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(url('forgot-password')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input class="input" type="email" name="email" placeholder="<?php echo e(__('web.email')); ?>">
                            <button type="submit" class="main-button icon-button pull-right"><?php echo e(__('web.submit')); ?></button>
                        </form>
                    </div>
                </div>
                <!-- /login form -->

            </div>
            <!-- /row -->

        </div>
        <!-- /container -->

    </div>
    <!-- /Contact -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skillshub\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>