<?php $__env->startSection('title'); ?>
Home Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>

    <!-- Home -->
    <div id="home" class="hero-area">

        <!-- Backgound Image -->
        <div class="bg-image bg-parallax overlay" style="background-image:url(<?php echo e(asset('web/img/home-background.jpg')); ?>)"></div>
        <!-- /Backgound Image -->

        <div class="home-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1 class="white-text"><?php echo e(__('web.head_title')); ?></h1>
                        <p class="lead white-text"><?php echo e(__('web.sub_title')); ?></p>
                        <a class="main-button icon-button" href="#"><?php echo e(__('web.get_started')); ?></a>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /Home -->

    <!-- Courses -->
    <div id="courses" class="section">

        <!-- container -->
        <div class="container">

            <!-- row -->
            <div class="row">
                <div class="section-header text-center">
                    <h2><?php echo e(__('web.popular_exams')); ?></h2>
                    <p class="lead"><?php echo e(__('web.exams_subtitle')); ?></p>
                </div>
            </div>
            <!-- /row -->

            <!-- courses -->
            <div id="courses-wrapper">

                <!-- row -->
                <div class="row">
                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <!-- single course -->
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <div class="course">
                            <a href="<?php echo e(url("skills/show/$skill->id")); ?>" class="course-img">
                                <img src="<?php echo e(asset('uploads/skills/1.png')); ?>" alt="">
                                <i class="course-link-icon fa fa-link"></i>
                            </a>
                            <a class="course-title" href="#"><?php echo e($skill->name()); ?></a>
                            <div class="course-details">
                                <span class="course-category"><?php echo e($skill->cat); ?></span>
                            </div>
                        </div>
                    </div>
                    <!-- /single course -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                <!-- /row -->

                

            </div>
            <!-- /courses -->

            <div class="row">
                <div class="center-btn">
                    <a class="main-button icon-button" href="#"><?php echo e(__('web.more_courses')); ?></a>
                </div>
            </div>

        </div>
        <!-- container -->

    </div>
    <!-- /Courses -->



    <!-- Contact CTA -->
    <div id="contact-cta" class="section">

        <!-- Backgound Image -->
        <div class="bg-image bg-parallax overlay" style="background-image:url(<?php echo e(asset('web/img/cta.jpg')); ?>)"></div>
        <!-- Backgound Image -->

        <!-- container -->
        <div class="container">

            <!-- row -->
            <div class="row">

                <div class="col-md-8 col-md-offset-2 text-center">
                    <h2 class="white-text"><?php echo e(__('web.contact')); ?></h2>
                    <p class="lead white-text"><?php echo e(__('web.contact_us_title')); ?></p>
                    <a class="main-button icon-button" href="<?php echo e(url('/contact')); ?>"><?php echo e(__('web.contact_now')); ?></a>
                </div>

            </div>
            <!-- /row -->

        </div>
        <!-- /container -->

    </div>
    <!-- /Contact CTA -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skillshub\resources\views/web/home/index.blade.php ENDPATH**/ ?>