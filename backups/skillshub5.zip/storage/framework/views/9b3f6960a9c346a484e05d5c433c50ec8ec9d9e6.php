<?php $__env->startSection('title'); ?>
    <?php echo e($skill->name()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>

    <!-- Hero-area -->
    <div class="hero-area section">

        <!-- Backgound Image -->
        <div class="bg-image bg-parallax overlay"
            style="background-image:url(<?php echo e(asset('web/img/page-background.jpg')); ?>)">
        </div>
        <!-- /Backgound Image -->

        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 text-center">
                    <ul class="hero-area-tree">
                        <li><a href="index.html"><?php echo e(__('web.home')); ?></a></li>
                        <li><a href="category.html"><?php echo e($skill->cat->name()); ?></a></li>
                        <li><?php echo e($skill->name()); ?></li>
                    </ul>
                    <h1 class="white-text"><?php echo e($skill->name()); ?></h1>

                </div>
            </div>
        </div>

    </div>
    <!-- /Hero-area -->

    <!-- Blog -->
    <div id="blog" class="section">

        <!-- container -->
        <div class="container">

            <!-- row -->
            <div class="row">

                <!-- main blog -->
                <div id="main" class="col-md-12">

                    <!-- row -->
                    <div class="row">
                        <?php $__currentLoopData = $skill->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- single exam -->
                            <div class="col-md-3">
                                <div class="single-blog">
                                    <div class="blog-img">
                                        <a href="<?php echo e(url("exams/show/$exam->id")); ?>">
                                            <img src="<?php echo e(asset("uploads/$exam->img")); ?>" alt="">
                                        </a>
                                    </div>
                                    <h4><a href="<?php echo e(url("exams/show/$exam->id")); ?>"><?php echo e($exam->name()); ?></a></h4>
                                    <div class="blog-meta">
                                        <span><?php echo e(Carbon\Carbon::parse($exam->created_at)->format('d M, Y')); ?></span>
                                        <div class="pull-right">
                                            <span class="blog-meta-comments"><a href="#"><i class="fa fa-users"></i>
                                                    <?php echo e($exam->users()->count()); ?></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /single exam -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- /row -->

                </div>
                <!-- /main blog -->

            </div>
            <!-- row -->

        </div>
        <!-- container -->

    </div>
    <!-- /Blog -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skillshub\resources\views/web/skills/show.blade.php ENDPATH**/ ?>