<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>SkillsHub - <?php echo $__env->yieldContent('title'); ?></title>

    <?php if(App::getLocale() == 'ar'): ?>
        <style>
            html {
                direction: rtl;
            }

        </style>
    <?php else: ?>
        <style>
            html {
                direction: ltr;
            }

        </style>
    <?php endif; ?>
    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Lato:700%7CMontserrat:400,600" rel="stylesheet">

    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('web/css/bootstrap.min.css')); ?>" />

    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="<?php echo e(asset('web/css/font-awesome.min.css')); ?>">

    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('web/css/style.css')); ?>" />
    <?php echo $__env->yieldContent('styles'); ?>

    <style>
        input:checked ~ .checkmark:after {
            background-color: #FF6700;
        }
    </style>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>

<body>

    <!-- Header -->
    <header id="header">
        <div class="container">

            <div class="navbar-header">
                <!-- Logo -->
                <div class="navbar-brand">
                    <a class="logo" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('web/img/logo.png')); ?>" alt="logo">
                    </a>
                </div>
                <!-- /Logo -->

                <!-- Mobile toggle -->
                <button class="navbar-toggle">
                    <span></span>
                </button>
                <!-- /Mobile toggle -->
            </div>

            <!-- Navigation -->
            <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, []); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <!-- /Navigation -->
        </div>
    </header>
    <!-- /Header -->
    <?php echo $__env->yieldContent('main'); ?>

    <!-- Footer -->
    <footer id="footer" class="section">

        <!-- container -->
        <div class="container">

            <!-- row -->
            <div id="bottom-footer" class="row">

                <!-- social -->
                <?php if (isset($component)) { $__componentOriginal355b43d127242619ccb1c95a680b7b9a3dcbf358 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SocialLinks::class, []); ?>
<?php $component->withName('social-links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal355b43d127242619ccb1c95a680b7b9a3dcbf358)): ?>
<?php $component = $__componentOriginal355b43d127242619ccb1c95a680b7b9a3dcbf358; ?>
<?php unset($__componentOriginal355b43d127242619ccb1c95a680b7b9a3dcbf358); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <!-- /social -->

                <!-- copyright -->
                <div class="col-md-8 col-md-pull-4">
                    <div class="footer-copyright">
                        <span>&copy; Copyright 2021. All Rights Reserved. | Made with <i class="fa fa-heart-o"
                                aria-hidden="true"></i> by <a href="#">SkillsHub</a></span>
                    </div>
                </div>
                <!-- /copyright -->

            </div>
            <!-- row -->

        </div>
        <!-- /container -->

    </footer>
    <!-- /Footer -->

    <!-- preloader -->
    <div id='preloader'>
        <div class='preloader'></div>
    </div>
    <!-- /preloader -->


    <!-- jQuery Plugins -->
    <script type="text/javascript" src="<?php echo e(asset('web/js/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('web/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('web/js/main.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('web/js/jquery.nicescroll.min.js')); ?>"></script>
    <script>
        $("html").niceScroll({
            cursorcolor: "#FF6700",
            cursorwidth: "6px",
            railpadding: {
                top: 10,
                right: 5,
                left: 5,
                bottom: 10
            },
        });
    </script>
    <script>
        $("#logout-link").click(function(e) {
            e.preventDefault();
            $("#logout-form").submit();
        });
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\skillshub\resources\views/web/layout.blade.php ENDPATH**/ ?>