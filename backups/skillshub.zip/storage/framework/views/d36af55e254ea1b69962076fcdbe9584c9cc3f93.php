<?php $__env->startSection('title'); ?>
    categories: <?php echo e($cat->name()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>

    <!-- Hero-area -->
    <div class="hero-area section">

        <!-- Backgound Image -->
        <div class="bg-image bg-parallax overlay"
            style="background-image:url(<?php echo e(asset('web/img/page-background.jpg')); ?>)">
        </div>
        <!-- /Backgound Image -->

        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 text-center">
                    <ul class="hero-area-tree">
                        <li><a href="index.html"><?php echo e(__('web.home')); ?></a></li>
                        <li><?php echo e($cat->name()); ?></li>
                    </ul>
                    <h1 class="white-text"><?php echo e($cat->name()); ?></h1>

                </div>
            </div>
        </div>

    </div>
    <!-- /Hero-area -->

    <!-- Blog -->
    <div id="blog" class="section">

        <!-- container -->
        <div class="container">

            <!-- row -->
            <div class="row">

                <!-- main blog -->
                <div id="main" class="col-md-9">

                    <!-- row -->
                    <div class="row">

                        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- single skill -->
                            <div class="col-md-4">
                                <div class="single-blog">
                                    <div class="blog-img">
                                        <a href="<?php echo e(url("exams/show/$skill->id")); ?>">
                                            <img src="<?php echo e(asset("uploads/$skill->img")); ?>" alt="">
                                        </a>
                                    </div>
                                    <h4><a href="skill.html">Pro eu error molestie deserunt. At per viderer bonorum
                                            persecuti.</a></h4>
                                    <div class="blog-meta">
                                        
                                        <span><?php echo e(Carbon\Carbon::parse($skill->created_at)->format('d M, Y')); ?></span>

                                        <div class="pull-right">
                                            <span class="blog-meta-comments"><a href="#"><i class="fa fa-users"></i>
                                                    <?php echo e($skill->getStudentsCount()); ?></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /single skill -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>
                    <!-- /row -->

                    <!-- row -->
                    <div class="row">

                    <?php echo e($skills->links('web.includes.paginator')); ?>


                    </div>
                    <!-- /row -->
                </div>
                <!-- /main blog -->

                <!-- aside blog -->
                <div id="aside" class="col-md-3">

                    <!-- search widget -->
                    <div class="widget search-widget">
                        <form>
                            <input class="input" type="text" name="search">
                            <button><i class="fa fa-search"></i></button>
                        </form>
                    </div>
                    <!-- /search widget -->

                    <!-- category widget -->
                    <div class="widget category-widget">
                        <h3>Categories</h3>
                        <?php $__currentLoopData = $all_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="category"
                                href="<?php echo e(url("categories/show/$one_cat->id")); ?>"><?php echo e($one_cat->name()); ?><span><?php echo e($one_cat->skills()->count()); ?></span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- /category widget -->
                </div>
                <!-- /aside blog -->

            </div>
            <!-- row -->

        </div>
        <!-- container -->

    </div>
    <!-- /Blog -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skillshub\resources\views/web/cats/show.blade.php ENDPATH**/ ?>