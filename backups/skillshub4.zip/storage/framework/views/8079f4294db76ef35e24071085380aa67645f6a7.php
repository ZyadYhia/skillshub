<?php if($paginator->hasPages()): ?>
    <!-- pagination -->
    <div class="col-md-12">
        <div class="post-pagination">
            <?php if($paginator->onFirstPage()): ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="btn disabled pagination-back pull-left">Back</a>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="pagination-back pull-left">Back</a>
            <?php endif; ?>
            <ul class="pages">

                
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(is_string($element)): ?>
                        <li class="page-item disabled" aria-disabled="true"><span
                                class="page-link"><?php echo e($element); ?></span></li>
                    <?php endif; ?>

                    
                    <?php if(is_array($element)): ?>
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $paginator->currentPage()): ?>
                            <li class="active"><?php echo e($page); ?></li>
                            <?php else: ?>
                            <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="pagination-next pull-right">Next</a>
            <?php else: ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="btn disabled pagination-next pull-right">Next</a>
            <?php endif; ?>
        </div>
    </div>
    <!-- pagination -->
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\skillshub\resources\views/web/includes/paginator.blade.php ENDPATH**/ ?>