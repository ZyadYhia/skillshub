
<nav id="nav">
    <ul class="main-menu nav navbar-nav navbar-right">
        <li><a href="<?php echo e(url('')); ?>"><?php echo e(__('web.home')); ?></a></li>
        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                aria-expanded="false"><?php echo e(__('web.cats')); ?> <span class="caret"></span></a>
            <ul class="dropdown-menu">
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url("categories/show/$cat->id")); ?>"><?php echo e($cat->name()); ?></a></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li><a href="<?php echo e(url('/contact')); ?>"><?php echo e(__('web.contact')); ?></a></li>
        <li><a href="<?php echo e(url('login')); ?>"><?php echo e(__('web.signin')); ?></a></li>
        <li><a href="<?php echo e(url('register')); ?>"><?php echo e(__('web.signup')); ?></a></li>

        <?php if(App::getLocale() == 'ar'): ?>
            <li><a href="<?php echo e(url('lang/set/en')); ?>">EN</a></li>
        <?php else: ?>
            <li><a href="<?php echo e(url('lang/set/ar')); ?>">ع</a></li>
        <?php endif; ?>
    </ul>
</nav>

<?php /**PATH C:\xampp\htdocs\skillshub\resources\views/components/navbar.blade.php ENDPATH**/ ?>