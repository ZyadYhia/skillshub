<?php $__env->startSection('title'); ?>
    register
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <!-- Hero-area -->
    <div class="hero-area section">

        <!-- Backgound Image -->
        <div class="bg-image bg-parallax overlay" style="background-image:url(<?php echo e(url('web/img/page-background.jpg')); ?>)"></div>
        <!-- /Backgound Image -->

        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 text-center">
                    <ul class="hero-area-tree">
                        <li><a href="index.html"><?php echo e(__('web.home')); ?></a></li>
                        <li><?php echo e(__('web.signup')); ?></li>
                    </ul>
                    <h1 class="white-text"><?php echo e(__('web.signup_sentence')); ?></h1>

                </div>
            </div>
        </div>

    </div>
    <!-- /Hero-area -->

    <!-- Contact -->
    <div id="contact" class="section">

        <!-- container -->
        <div class="container">

            <!-- row -->
            <div class="row">

                <!-- login form -->
                <div class="col-md-6 col-md-offset-3">
                    <div class="contact-form">
                        <h4><?php echo e(__('web.signup')); ?></h4>
                        <form method="POST" action="<?php echo e(url('/register')); ?>">
                            <?php echo csrf_field(); ?>
                            <input class="input" type="text" name="name" placeholder="<?php echo e(__('web.name')); ?>">
                            <input class="input" type="email" name="email" placeholder="<?php echo e(__('web.email')); ?>">
                            <input class="input" type="password" name="password" placeholder="<?php echo e(__('web.password')); ?>">
                            <input class="input" type="password" name="password_confirmation"
                                placeholder="<?php echo e(__('web.password_confirm')); ?>">
                            <button type="submit" class="main-button icon-button pull-right"><?php echo e(__('web.signup')); ?></button>
                        </form>
                    </div>
                </div>
                <!-- /login form -->

            </div>
            <!-- /row -->

        </div>
        <!-- /container -->

    </div>
    <!-- /Contact -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skillshub\resources\views/auth/register.blade.php ENDPATH**/ ?>